-- QRCraft PHP - MySQL Database Schema
-- Run this file first before starting the project

CREATE DATABASE IF NOT EXISTS qrcraft CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE qrcraft;

-- ─── USERS TABLE ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    role        ENUM('user','admin') DEFAULT 'user',
    is_banned   TINYINT(1) DEFAULT 0,
    ban_reason  VARCHAR(255) DEFAULT '',
    qr_count    INT DEFAULT 0,
    qr_limit    INT DEFAULT 3,
    last_login  DATETIME DEFAULT NULL,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ─── QR CODES TABLE ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS qr_codes (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,
    title        VARCHAR(150) NOT NULL,
    type         ENUM('url','text','image','video','profile') NOT NULL,
    content      TEXT DEFAULT '',
    file_url     VARCHAR(500) DEFAULT '',
    file_name    VARCHAR(255) DEFAULT '',
    file_size    INT DEFAULT 0,
    profile_data TEXT DEFAULT '',
    qr_image     LONGTEXT DEFAULT '',
    scan_count   INT DEFAULT 0,
    is_active    TINYINT(1) DEFAULT 1,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─── SCAN HISTORY TABLE ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS scan_history (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    qr_id       INT NOT NULL,
    scanned_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    ip_address  VARCHAR(100) DEFAULT '',
    user_agent  TEXT DEFAULT '',
    device      VARCHAR(50) DEFAULT 'Unknown',
    browser     VARCHAR(50) DEFAULT 'Unknown',
    os          VARCHAR(50) DEFAULT 'Unknown',
    country     VARCHAR(50) DEFAULT 'Unknown',
    FOREIGN KEY (qr_id) REFERENCES qr_codes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─── DEFAULT ADMIN USER ───────────────────────────────────────────────────
-- Password: admin123 (change this after first login!)
INSERT INTO users (name, email, password, role, qr_limit)
VALUES ('Admin', 'admin@qrcraft.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 999)
ON DUPLICATE KEY UPDATE id=id;

-- Indexes for performance
CREATE INDEX idx_qr_user ON qr_codes(user_id);
CREATE INDEX idx_scan_qr ON scan_history(qr_id);
CREATE INDEX idx_scan_date ON scan_history(scanned_at);
CREATE INDEX idx_user_email ON users(email);
