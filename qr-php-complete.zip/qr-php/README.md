# QRCraft — PHP + MySQL QR Code Generator
**Complete full-stack web application**

---

## 📋 Project Features

### 👤 User Features
- Register / Login / Logout (PHP Sessions)
- Create QR codes: URL, Text, Image, Video, vCard/Profile
- Live QR preview before saving (browser-side QRCode.js)
- Download QR as PNG
- View scan count per QR
- Delete QR codes
- Free limit: **3 QR codes** per user

### 📊 Analytics Features
- Total scans, today scans, weekly scans
- 30-day scan trend (Line chart)
- Hourly scan heatmap (Bar chart)
- Device breakdown (Mobile/Desktop/Tablet)
- Browser breakdown (Chrome/Firefox/Safari etc.)
- OS breakdown (Windows/Android/iOS etc.)
- Paginated scan history table

### ⚙️ Admin Features
- View all users with search
- Full user details + their QR codes
- Ban user (with reason) / Unban user
- Delete user (removes all their QRs too)
- Analytics dashboard (totals, QR by type, top QRs)
- Download CSV report (users + QR codes)

---

## 🗂️ File Structure & Explanation

```
qr-php/
│
├── index.php                  ← Home/Landing page
├── .htaccess                  ← Apache security config
│
├── config/
│   └── db.php                 ← MySQL connection + app constants
│
├── auth/
│   ├── login.php              ← Login page (form + logic)
│   ├── signup.php             ← Register page (form + logic)
│   ├── logout.php             ← Session destroy + redirect
│   └── forgot-password.php    ← Forgot password page
│
├── dashboard/
│   ├── index.php              ← User dashboard (QR list + stats)
│   └── create-qr.php          ← Create QR page (all 5 types)
│
├── analytics/
│   ├── index.php              ← Analytics overview (all QRs)
│   └── qr-detail.php          ← Per-QR analytics with charts
│
├── admin/
│   ├── index.php              ← Admin panel (analytics + users tabs)
│   ├── user-detail.php        ← Individual user details page
│   └── download-report.php    ← CSV report download
│
├── api/
│   ├── create-qr.php          ← POST: Create new QR (AJAX)
│   ├── delete-qr.php          ← GET: Delete QR by ID
│   ├── track-scan.php         ← GET: Track a QR scan (public)
│   ├── ban-user.php           ← POST: Ban user (admin only)
│   ├── unban-user.php         ← GET: Unban user (admin only)
│   └── delete-user.php        ← GET: Delete user (admin only)
│
├── includes/
│   ├── auth-check.php         ← requireLogin() + getCurrentUser()
│   ├── admin-check.php        ← requireAdmin() middleware
│   ├── ua-parser.php          ← Device/Browser/OS parser
│   ├── header.php             ← Common HTML <head>
│   ├── navbar.php             ← Navigation bar
│   └── footer.php             ← Common footer + JS
│
├── assets/
│   ├── css/main.css           ← Full dark theme CSS
│   └── js/main.js             ← Common JS (alerts etc.)
│
├── uploads/
│   ├── images/                ← Uploaded image files
│   └── videos/                ← Uploaded video files
│
└── database/
    └── schema.sql             ← MySQL tables + default admin
```

---

## 🔗 How Files Connect

```
User visits page
    ↓
config/db.php          → MySQL connection (used by ALL files)
includes/auth-check.php → Session check (used by dashboard, analytics, api)
includes/admin-check.php → Admin check (used by admin pages, admin APIs)
    ↓
Page loads data from MySQL via PDO
    ↓
includes/navbar.php    → Shown on every page
    ↓
Page output rendered
    ↓
assets/css/main.css    → Styling for all pages
assets/js/main.js      → Common JS for all pages
```

**QR Creation Flow:**
```
dashboard/create-qr.php  →  (AJAX POST)  →  api/create-qr.php
                                               ↓
                                          Saves to MySQL qr_codes table
                                          Saves file to uploads/ (if image/video)
                                               ↓
                                          Returns JSON → redirect to dashboard
```

**Scan Tracking Flow:**
```
Someone scans QR  →  api/track-scan.php?id=X
                          ↓
                    includes/ua-parser.php (parse device/browser/OS)
                          ↓
                    INSERT into scan_history table
                    UPDATE scan_count in qr_codes table
```

---

## 🗃️ Database Tables

| Table | Purpose |
|-------|---------|
| `users` | User accounts (id, name, email, password, role, is_banned) |
| `qr_codes` | QR code data (title, type, content, file_url, qr_image, scan_count) |
| `scan_history` | Every scan record (qr_id, device, browser, os, ip, scanned_at) |

---

## 💻 LOCAL Setup (XAMPP/WAMP)

### Step 1 — Install XAMPP
Download: https://www.apachefriends.org
Install karo → Apache + MySQL start karo

### Step 2 — Project Copy Karo
```
C:\xampp\htdocs\qr-php\   (Windows)
/Applications/XAMPP/htdocs/qr-php/   (Mac)
```
ZIP extract karke andar rakho

### Step 3 — Database Banao
1. Browser mein jao: http://localhost/phpmyadmin
2. New database banao: `qrcraft`
3. Import karo: `database/schema.sql` file

### Step 4 — Config Update Karo
`config/db.php` file kholo:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // XAMPP default
define('DB_PASS', '');           // XAMPP mein empty hota hai
define('DB_NAME', 'qrcraft');
define('APP_URL', 'http://localhost/qr-php');  // ← yahi rakho
```

### Step 5 — Uploads Folder Permission
```
uploads/images/  → writable hona chahiye
uploads/videos/  → writable hona chahiye
```
Windows par automatic hoga. Mac/Linux par:
```bash
chmod -R 755 uploads/
```

### Step 6 — Website Kholo
```
http://localhost/qr-php
```

### Default Admin Login
```
Email:    admin@qrcraft.com
Password: password
```
⚠️ **Pehla kaam: Admin ka password change karo!**

---

## 🌐 HOSTING Setup (cPanel/Shared Hosting)

### Step 1 — Files Upload Karo
- cPanel → File Manager → `public_html/qr-php/` folder banao
- Saari files ZIP karke upload karo → Extract karo

### Step 2 — MySQL Database Banao
1. cPanel → MySQL Databases
2. New database banao: `youruser_qrcraft`
3. New user banao + password set karo
4. User ko database assign karo (All Privileges)

### Step 3 — Schema Import Karo
1. cPanel → phpMyAdmin
2. Database select karo
3. Import tab → `database/schema.sql` select karo → Go

### Step 4 — Config Update Karo
`config/db.php` mein:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'youruser_qrcraft');  // jo banaya tha
define('DB_PASS', 'yourpassword');       // jo set kiya tha
define('DB_NAME', 'youruser_qrcraft');  // jo banaya tha
define('APP_URL', 'https://yourdomain.com/qr-php');
```

### Step 5 — PHP Version Check
cPanel → PHP Selector → **PHP 8.0+** select karo

### Step 6 — Folder Permissions
```
uploads/  → 755
uploads/images/ → 755
uploads/videos/ → 755
```

---

## ✅ Feature Checklist

| Feature | Status |
|---------|--------|
| User Registration/Login | ✅ |
| Session-based Auth | ✅ |
| URL QR Code | ✅ |
| Text QR Code | ✅ |
| Image QR Code | ✅ |
| Video QR Code | ✅ |
| vCard/Profile QR | ✅ |
| Live QR Preview | ✅ |
| Download QR PNG | ✅ |
| Scan Count Tracking | ✅ |
| Device/Browser/OS Detection | ✅ |
| 30-day Trend Chart | ✅ |
| Hourly Heatmap Chart | ✅ |
| Per-QR Analytics | ✅ |
| Admin — User List | ✅ |
| Admin — Ban/Unban | ✅ |
| Admin — Delete User | ✅ |
| Admin — User Details | ✅ |
| Admin — CSV Report | ✅ |
| Free QR Limit (3) | ✅ |
| Dark Theme UI | ✅ |
| Mobile Responsive | ✅ |

---

## ⚙️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Language | PHP 8.0+ |
| Database | MySQL 5.7+ / MariaDB |
| Frontend | HTML5, CSS3, Vanilla JS |
| QR Generation | QRCode.js (browser-side) |
| Charts | Chart.js 4 |
| DB Connection | PDO (prepared statements) |
| Auth | PHP Sessions |
| File Upload | PHP $_FILES |
| Server | Apache (XAMPP/cPanel) |

---

## 🔒 Security Features
- PDO prepared statements (SQL injection se bachao)
- `password_hash()` + `password_verify()` (bcrypt)
- `htmlspecialchars()` on all output (XSS se bachao)
- Session-based auth with ban check on every request
- File upload validation (type + size check)
- PHP execution disabled in uploads folder (.htaccess)
- Admin routes protected by separate middleware
