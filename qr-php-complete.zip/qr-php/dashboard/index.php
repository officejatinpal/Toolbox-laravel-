<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth-check.php';
requireLogin();

$user = getCurrentUser();
$db   = getDB();

// Stats
$qrs   = $db->prepare("SELECT * FROM qr_codes WHERE user_id = ? ORDER BY created_at DESC");
$qrs->execute([$user['id']]);
$myQRs = $qrs->fetchAll();

$totalScans = array_sum(array_column($myQRs, 'scan_count'));
$remaining  = max(0, $user['qr_limit'] - $user['qr_count']);

$pageTitle = 'Dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — QRCraft</title>
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/main.css">
</head>
<body>
<?php require_once __DIR__ . '/../includes/navbar.php'; ?>

<div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-section">
            <div style="padding:0 12px;margin-bottom:1.5rem">
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
                    <div style="width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,var(--accent),#a855f7);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1rem">
                        <?= strtoupper(substr($user['name'], 0, 1)) ?>
                    </div>
                    <div>
                        <div style="font-weight:700;font-size:.9rem"><?= htmlspecialchars($user['name']) ?></div>
                        <div style="font-size:.75rem;color:var(--text-muted)"><?= htmlspecialchars($user['email']) ?></div>
                    </div>
                </div>
                <div style="background:var(--bg-hover);border-radius:8px;padding:8px 10px;font-size:.8rem">
                    <div style="display:flex;justify-content:space-between;margin-bottom:4px">
                        <span style="color:var(--text-secondary)">QR Codes</span>
                        <span style="font-weight:700;font-family:var(--font-mono)"><?= $user['qr_count'] ?>/<?= $user['qr_limit'] ?></span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-bar-fill" style="width:<?= min(100, ($user['qr_count'] / max(1,$user['qr_limit'])) * 100) ?>%"></div>
                    </div>
                    <div style="color:var(--text-muted);margin-top:4px"><?= $remaining ?> remaining</div>
                </div>
            </div>
            <div class="sidebar-label">Navigation</div>
            <a href="<?= APP_URL ?>/dashboard/index.php" class="sidebar-item active">
                <span class="item-icon">⬛</span> My QR Codes
            </a>
            <a href="<?= APP_URL ?>/dashboard/create-qr.php" class="sidebar-item">
                <span class="item-icon">➕</span> Create QR
            </a>
            <a href="<?= APP_URL ?>/analytics/index.php" class="sidebar-item">
                <span class="item-icon">📊</span> Analytics
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="dashboard-content">
        <!-- Stats -->
        <div class="stats-grid" style="margin-bottom:1.5rem">
            <div class="stat-card">
                <div class="stat-label">My QR Codes</div>
                <div class="stat-value" style="color:var(--accent)"><?= count($myQRs) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Total Scans</div>
                <div class="stat-value" style="color:var(--green)"><?= $totalScans ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Remaining Free</div>
                <div class="stat-value" style="color:var(--yellow)"><?= $remaining ?></div>
            </div>
        </div>

        <?php if (isset($_GET['msg'])): ?>
            <div class="alert alert-success" style="margin-bottom:1rem">✅ <?= htmlspecialchars($_GET['msg']) ?></div>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-error" style="margin-bottom:1rem">⚠️ <?= htmlspecialchars($_GET['error']) ?></div>
        <?php endif; ?>

        <div class="page-header">
            <div>
                <h1 class="page-title">My QR Codes</h1>
                <p class="page-subtitle"><?= count($myQRs) ?> QR code<?= count($myQRs) !== 1 ? 's' : '' ?> created</p>
            </div>
            <a href="<?= APP_URL ?>/dashboard/create-qr.php" class="btn btn-primary">➕ Create New</a>
        </div>

        <?php if (empty($myQRs)): ?>
            <div class="empty-state">
                <div class="empty-icon">⬛</div>
                <h3>No QR codes yet</h3>
                <p>Create your first QR code to get started</p>
                <a href="<?= APP_URL ?>/dashboard/create-qr.php" class="btn btn-primary">➕ Create QR Code</a>
            </div>
        <?php else: ?>
            <div class="qr-grid">
                <?php foreach ($myQRs as $qr): ?>
                    <div class="qr-card">
                        <div class="qr-card-preview">
                            <?php if ($qr['qr_image']): ?>
                                <img src="<?= $qr['qr_image'] ?>" alt="<?= htmlspecialchars($qr['title']) ?>">
                            <?php else: ?>
                                <div style="font-size:3rem;opacity:.2">⬛</div>
                            <?php endif; ?>
                        </div>
                        <div class="qr-card-body">
                            <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:6px">
                                <div class="qr-card-title" title="<?= htmlspecialchars($qr['title']) ?>"><?= htmlspecialchars($qr['title']) ?></div>
                                <span class="badge badge-purple"><?= strtoupper($qr['type']) ?></span>
                            </div>
                            <div class="qr-card-meta">
                                <span>👁 <?= $qr['scan_count'] ?> scans</span>
                                <span>•</span>
                                <span><?= date('d M Y', strtotime($qr['created_at'])) ?></span>
                            </div>
                            <?php if ($qr['content']): ?>
                                <div style="margin-top:8px;font-size:.78rem;color:var(--text-muted);word-break:break-all;overflow:hidden;max-height:36px">
                                    <?= htmlspecialchars(substr($qr['content'], 0, 80)) ?>
                                </div>
                            <?php endif; ?>
                            <div class="qr-card-actions">
                                <?php if ($qr['qr_image']): ?>
                                    <a href="<?= $qr['qr_image'] ?>" download="<?= htmlspecialchars($qr['title']) ?>.png" class="btn btn-secondary btn-sm" style="flex:1">⬇ Save</a>
                                <?php endif; ?>
                                <a href="<?= APP_URL ?>/analytics/qr-detail.php?id=<?= $qr['id'] ?>" class="btn btn-secondary btn-sm" style="flex:1">📊 Stats</a>
                                <a href="<?= APP_URL ?>/api/delete-qr.php?id=<?= $qr['id'] ?>"
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Delete this QR code?')">🗑</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
