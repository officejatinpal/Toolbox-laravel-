<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth-check.php';
requireLogin();
$user      = getCurrentUser();
$remaining = max(0, $user['qr_limit'] - $user['qr_count']);
$pageTitle = 'Create QR';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create QR — QRCraft</title>
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/main.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
</head>
<body>
<?php require_once __DIR__ . '/../includes/navbar.php'; ?>

<div class="dashboard-layout">
    <aside class="sidebar">
        <div class="sidebar-section">
            <div class="sidebar-label">Navigation</div>
            <a href="<?= APP_URL ?>/dashboard/index.php" class="sidebar-item"><span class="item-icon">⬛</span> My QR Codes</a>
            <a href="<?= APP_URL ?>/dashboard/create-qr.php" class="sidebar-item active"><span class="item-icon">➕</span> Create QR</a>
            <a href="<?= APP_URL ?>/analytics/index.php" class="sidebar-item"><span class="item-icon">📊</span> Analytics</a>
        </div>
    </aside>

    <main class="dashboard-content">
        <div class="page-header">
            <div>
                <h1 class="page-title">Create QR Code</h1>
                <p class="page-subtitle">Generate a new QR code for any type of content</p>
            </div>
        </div>

        <?php if ($remaining <= 0 && $user['role'] !== 'admin'): ?>
            <div class="limit-banner">
                🔒 <div><strong>Free limit reached.</strong> You've used all <?= $user['qr_limit'] ?> free QR codes.</div>
            </div>
        <?php else: ?>
            <?php if ($remaining <= $user['qr_limit']): ?>
                <div style="background:var(--yellow-light);border:1px solid rgba(245,158,11,.3);border-radius:var(--radius);padding:10px 14px;margin-bottom:1rem;font-size:.875rem;display:flex;align-items:center;gap:8px">
                    ⚡ <span><strong><?= $remaining ?></strong> free QR<?= $remaining !== 1 ? 's' : ''?> remaining</span>
                    <div style="flex:1"><div class="progress-bar"><div class="progress-bar-fill" style="width:<?= min(100,(($user['qr_limit']-$remaining)/max(1,$user['qr_limit']))*100) ?>%"></div></div></div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <div id="msg-area"></div>

        <div class="generator-layout">
            <div>
                <!-- Type Selector -->
                <div class="form-group">
                    <label class="form-label">QR Type</label>
                    <div class="type-selector">
                        <?php foreach([['url','🔗','URL'],['text','📝','Text'],['image','🖼️','Image'],['video','🎬','Video'],['profile','👤','vCard']] as $t): ?>
                            <button type="button" class="type-btn <?= $t[0]==='url'?'active':'' ?>" onclick="switchType('<?= $t[0] ?>')">
                                <span class="type-icon"><?= $t[1] ?></span><?= $t[2] ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>

                <form id="qr-form" enctype="multipart/form-data">
                    <input type="hidden" name="type" id="type-input" value="url">

                    <div class="form-group">
                        <label class="form-label">Title</label>
                        <input type="text" name="title" class="form-input" placeholder="My QR Code name..." required <?= $remaining<=0&&$user['role']!=='admin'?'disabled':''?>>
                    </div>

                    <!-- URL -->
                    <div id="section-url">
                        <div class="form-group">
                            <label class="form-label">URL</label>
                            <input type="url" name="content_url" class="form-input" placeholder="https://example.com" id="content-url">
                        </div>
                    </div>

                    <!-- Text -->
                    <div id="section-text" style="display:none">
                        <div class="form-group">
                            <label class="form-label">Text Content</label>
                            <textarea name="content_text" class="form-input" placeholder="Enter any text here..." id="content-text"></textarea>
                        </div>
                    </div>

                    <!-- Image -->
                    <div id="section-image" style="display:none">
                        <div class="form-group">
                            <label class="form-label">Image File</label>
                            <div class="file-drop-zone" onclick="document.getElementById('img-file').click()">
                                <div class="drop-icon">🖼️</div>
                                <div class="drop-text">Click to browse image</div>
                                <div class="drop-hint">JPG, PNG, GIF, WebP — max 10MB</div>
                                <input type="file" id="img-file" name="file" accept="image/*" style="display:none" onchange="showFileName(this)">
                            </div>
                            <div id="img-name" style="margin-top:8px;font-size:.85rem;color:var(--text-secondary)"></div>
                        </div>
                    </div>

                    <!-- Video -->
                    <div id="section-video" style="display:none">
                        <div class="form-group">
                            <label class="form-label">Video File</label>
                            <div class="file-drop-zone" onclick="document.getElementById('vid-file').click()">
                                <div class="drop-icon">🎬</div>
                                <div class="drop-text">Click to browse video</div>
                                <div class="drop-hint">MP4, MOV, AVI — max 50MB</div>
                                <input type="file" id="vid-file" name="file" accept="video/*" style="display:none" onchange="showFileName(this)">
                            </div>
                            <div id="vid-name" style="margin-top:8px;font-size:.85rem;color:var(--text-secondary)"></div>
                        </div>
                    </div>

                    <!-- Profile -->
                    <div id="section-profile" style="display:none">
                        <div class="form-group">
                            <label class="form-label">vCard Details</label>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
                                <?php foreach([
                                    ['profile_first','First Name','John',true],
                                    ['profile_last','Last Name','Doe',true],
                                    ['profile_phone','Phone','+91 98765 43210',true],
                                    ['profile_email','Email','john@example.com',true],
                                    ['profile_org','Organization','Company Name',false],
                                    ['profile_website','Website','https://johndoe.com',false],
                                    ['profile_address','Address','City, Country',false],
                                ] as $f): ?>
                                    <div style="grid-column:<?= $f[3]?'span 1':'span 2' ?>">
                                        <div style="font-size:.78rem;color:var(--text-muted);margin-bottom:3px;font-weight:600;text-transform:uppercase;letter-spacing:.04em"><?= $f[1] ?></div>
                                        <input type="text" name="<?= $f[0] ?>" class="form-input" style="padding:9px 12px;font-size:.875rem" placeholder="<?= $f[2] ?>">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <button type="button" id="gen-btn" class="btn btn-primary btn-full btn-lg"
                        onclick="generateQR()" <?= $remaining<=0&&$user['role']!=='admin'?'disabled':''?>>
                        ✨ Generate QR Code
                    </button>
                </form>
            </div>

            <!-- Live Preview -->
            <div class="qr-preview-box">
                <h3 style="margin-bottom:1.25rem;color:var(--text-secondary);font-size:.875rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em">Live Preview</h3>
                <div class="qr-preview-inner">
                    <div id="qr-preview-placeholder" class="qr-placeholder">
                        <span class="qr-placeholder-icon">⬛</span>
                        <span>Fill in the form to preview</span>
                    </div>
                    <div id="qr-canvas" style="display:none"></div>
                </div>
                <div id="qr-actions" style="display:none;margin-top:1rem">
                    <p style="font-size:.8rem;color:var(--text-muted);margin-bottom:1rem">Preview ready — click Generate to save</p>
                    <button class="btn btn-secondary btn-full" onclick="downloadPreview()">⬇ Download Preview</button>
                </div>
            </div>
        </div>
    </main>
</div>

<script>
let currentType = 'url';
let qrInstance  = null;
let previewTimer = null;

function switchType(type) {
    currentType = type;
    document.getElementById('type-input').value = type;
    ['url','text','image','video','profile'].forEach(t => {
        document.getElementById('section-' + t).style.display = t === type ? 'block' : 'none';
    });
    document.querySelectorAll('.type-btn').forEach(b => b.classList.remove('active'));
    event.currentTarget.classList.add('active');
    updatePreview();
}

function getContent() {
    if (currentType === 'url')  return document.getElementById('content-url').value;
    if (currentType === 'text') return document.getElementById('content-text').value;
    if (currentType === 'profile') {
        const g = n => document.querySelector('[name="' + n + '"]')?.value || '';
        return `BEGIN:VCARD\nVERSION:3.0\nFN:${g('profile_first')} ${g('profile_last')}\nTEL:${g('profile_phone')}\nEMAIL:${g('profile_email')}\nORG:${g('profile_org')}\nURL:${g('profile_website')}\nADR:${g('profile_address')}\nEND:VCARD`;
    }
    return 'File QR - ' + new Date().toISOString();
}

function updatePreview() {
    clearTimeout(previewTimer);
    previewTimer = setTimeout(() => {
        const content = getContent();
        if (!content.trim()) {
            document.getElementById('qr-canvas').style.display = 'none';
            document.getElementById('qr-preview-placeholder').style.display = 'flex';
            document.getElementById('qr-actions').style.display = 'none';
            return;
        }
        document.getElementById('qr-canvas').innerHTML = '';
        document.getElementById('qr-canvas').style.display = 'block';
        document.getElementById('qr-preview-placeholder').style.display = 'none';
        try {
            qrInstance = new QRCode(document.getElementById('qr-canvas'), {
                text: content, width: 200, height: 200,
                colorDark: '#000000', colorLight: '#ffffff',
                correctLevel: QRCode.CorrectLevel.M
            });
            document.getElementById('qr-actions').style.display = 'block';
        } catch(e) {}
    }, 300);
}

function getQRDataURL() {
    const img = document.querySelector('#qr-canvas img');
    const can = document.querySelector('#qr-canvas canvas');
    if (img && img.src) return img.src;
    if (can) return can.toDataURL('image/png');
    return '';
}

function downloadPreview() {
    const url = getQRDataURL();
    if (!url) return;
    const a = document.createElement('a');
    a.href = url; a.download = 'preview-qr.png'; a.click();
}

function showFileName(input) {
    const id = input.id === 'img-file' ? 'img-name' : 'vid-name';
    document.getElementById(id).textContent = input.files[0]?.name || '';
    updatePreview();
}

function generateQR() {
    const title = document.querySelector('[name="title"]').value.trim();
    if (!title) { showMsg('Title is required', 'error'); return; }

    const qrDataURL = getQRDataURL();
    const btn = document.getElementById('gen-btn');
    btn.disabled = true;
    btn.innerHTML = '⏳ Saving...';

    const formData = new FormData(document.getElementById('qr-form'));
    formData.append('qr_image', qrDataURL);
    formData.append('content', getContent());

    fetch('<?= APP_URL ?>/api/create-qr.php', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                showMsg('✅ QR created successfully! Redirecting...', 'success');
                setTimeout(() => window.location = '<?= APP_URL ?>/dashboard/index.php?msg=QR+created+successfully', 1500);
            } else {
                showMsg(data.message || 'Failed', 'error');
                btn.disabled = false;
                btn.innerHTML = '✨ Generate QR Code';
            }
        })
        .catch(() => { showMsg('Network error', 'error'); btn.disabled = false; btn.innerHTML = '✨ Generate QR Code'; });
}

function showMsg(msg, type) {
    document.getElementById('msg-area').innerHTML =
        `<div class="alert alert-${type === 'success' ? 'success' : 'error'}" style="margin-bottom:1rem">${msg}</div>`;
}

// Live preview on input
document.addEventListener('input', e => {
    if (['content-url','content-text'].includes(e.target.id) || e.target.name?.startsWith('profile_')) updatePreview();
});
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
