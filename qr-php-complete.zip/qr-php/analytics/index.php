<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth-check.php';
requireLogin();

$user = getCurrentUser();
$db   = getDB();
$uid  = $user['id'];

// All QRs
$qrs = $db->prepare("SELECT * FROM qr_codes WHERE user_id = ? ORDER BY scan_count DESC");
$qrs->execute([$uid]);
$myQRs = $qrs->fetchAll();

$totalQRs   = count($myQRs);
$totalScans = array_sum(array_column($myQRs, 'scan_count'));

// Today's scans
$today = $db->prepare("SELECT COUNT(*) FROM scan_history sh JOIN qr_codes q ON sh.qr_id=q.id WHERE q.user_id=? AND DATE(sh.scanned_at)=CURDATE()");
$today->execute([$uid]);
$scansToday = $today->fetchColumn();

// This week
$week = $db->prepare("SELECT COUNT(*) FROM scan_history sh JOIN qr_codes q ON sh.qr_id=q.id WHERE q.user_id=? AND sh.scanned_at >= DATE_SUB(NOW(),INTERVAL 7 DAY)");
$week->execute([$uid]);
$scansWeek = $week->fetchColumn();

// Last 30 days trend
$trend = $db->prepare("SELECT DATE(sh.scanned_at) as d, COUNT(*) as cnt FROM scan_history sh JOIN qr_codes q ON sh.qr_id=q.id WHERE q.user_id=? AND sh.scanned_at >= DATE_SUB(NOW(),INTERVAL 30 DAY) GROUP BY DATE(sh.scanned_at) ORDER BY d");
$trend->execute([$uid]);
$trendRaw = $trend->fetchAll();
$trendMap = [];
foreach ($trendRaw as $r) $trendMap[$r['d']] = (int)$r['cnt'];
$trendData = [];
for ($i = 29; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $trendData[] = ['date' => $d, 'count' => $trendMap[$d] ?? 0];
}

// Device stats
$devQ = $db->prepare("SELECT sh.device, COUNT(*) as cnt FROM scan_history sh JOIN qr_codes q ON sh.qr_id=q.id WHERE q.user_id=? GROUP BY sh.device ORDER BY cnt DESC");
$devQ->execute([$uid]); $deviceStats = $devQ->fetchAll();

// Browser stats
$brQ = $db->prepare("SELECT sh.browser, COUNT(*) as cnt FROM scan_history sh JOIN qr_codes q ON sh.qr_id=q.id WHERE q.user_id=? GROUP BY sh.browser ORDER BY cnt DESC");
$brQ->execute([$uid]); $browserStats = $brQ->fetchAll();

// OS stats
$osQ = $db->prepare("SELECT sh.os, COUNT(*) as cnt FROM scan_history sh JOIN qr_codes q ON sh.qr_id=q.id WHERE q.user_id=? GROUP BY sh.os ORDER BY cnt DESC");
$osQ->execute([$uid]); $osStats = $osQ->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics — QRCraft</title>
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/main.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
</head>
<body>
<?php require_once __DIR__ . '/../includes/navbar.php'; ?>

<div class="dashboard-layout">
    <aside class="sidebar">
        <div class="sidebar-section">
            <div class="sidebar-label">Navigation</div>
            <a href="<?= APP_URL ?>/dashboard/index.php" class="sidebar-item"><span class="item-icon">⬛</span> My QR Codes</a>
            <a href="<?= APP_URL ?>/dashboard/create-qr.php" class="sidebar-item"><span class="item-icon">➕</span> Create QR</a>
            <a href="<?= APP_URL ?>/analytics/index.php" class="sidebar-item active"><span class="item-icon">📊</span> Analytics</a>
        </div>
    </aside>

    <main class="dashboard-content">
        <div class="page-header">
            <div>
                <h1 class="page-title">📊 Analytics</h1>
                <p class="page-subtitle">Track scans across all your QR codes</p>
            </div>
        </div>

        <!-- Stats -->
        <div class="stats-grid" style="margin-bottom:1.5rem">
            <div class="stat-card"><div class="stat-label">Total QR Codes</div><div class="stat-value" style="color:var(--accent)"><?= $totalQRs ?></div></div>
            <div class="stat-card"><div class="stat-label">Total Scans</div><div class="stat-value" style="color:var(--green)"><?= $totalScans ?></div></div>
            <div class="stat-card"><div class="stat-label">Scans Today</div><div class="stat-value" style="color:var(--yellow)"><?= $scansToday ?></div></div>
            <div class="stat-card"><div class="stat-label">This Week</div><div class="stat-value" style="color:var(--blue)"><?= $scansWeek ?></div></div>
        </div>

        <!-- Line Chart: Trend -->
        <div class="card" style="margin-bottom:1.5rem">
            <div class="card-header"><span class="card-title">📈 Scans Over Last 30 Days</span></div>
            <div class="card-body"><canvas id="trendChart" height="80"></canvas></div>
        </div>

        <!-- Bar Chart: Per QR -->
        <?php if (!empty($myQRs)): ?>
        <div class="card" style="margin-bottom:1.5rem">
            <div class="card-header"><span class="card-title">📊 Scans per QR Code</span></div>
            <div class="card-body"><canvas id="barChart" height="80"></canvas></div>
        </div>
        <?php endif; ?>

        <!-- Device / Browser / OS -->
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:1.25rem;margin-bottom:1.5rem">
            <div class="card"><div class="card-header"><span class="card-title">📱 Device Type</span></div>
                <div class="card-body"><canvas id="deviceChart" height="120"></canvas></div></div>
            <div class="card"><div class="card-header"><span class="card-title">🌐 Browser</span></div>
                <div class="card-body"><canvas id="browserChart" height="120"></canvas></div></div>
            <div class="card"><div class="card-header"><span class="card-title">💻 OS</span></div>
                <div class="card-body"><canvas id="osChart" height="120"></canvas></div></div>
        </div>

        <!-- QR List Table -->
        <div class="card">
            <div class="card-header"><span class="card-title">🔍 Drill Down by QR Code</span></div>
            <div class="admin-table-wrap">
                <table class="admin-table">
                    <thead><tr><th>QR Code</th><th>Type</th><th>Total Scans</th><th>Created</th><th></th></tr></thead>
                    <tbody>
                    <?php if (empty($myQRs)): ?>
                        <tr><td colspan="5" style="text-align:center;padding:2rem;color:var(--text-muted)">No QR codes yet</td></tr>
                    <?php else: foreach ($myQRs as $qr): ?>
                        <tr>
                            <td>
                                <div style="display:flex;align-items:center;gap:10px">
                                    <?php if ($qr['qr_image']): ?><img src="<?= $qr['qr_image'] ?>" style="width:32px;height:32px;background:white;padding:2px;border-radius:4px"><?php endif; ?>
                                    <div>
                                        <div style="font-weight:600"><?= htmlspecialchars($qr['title']) ?></div>
                                        <?php if ($qr['content']): ?><div style="font-size:.75rem;color:var(--text-muted);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars(substr($qr['content'],0,60)) ?></div><?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td><span class="badge badge-purple"><?= strtoupper($qr['type']) ?></span></td>
                            <td><span style="font-family:var(--font-mono);font-weight:700;font-size:1.1rem;color:var(--accent)"><?= $qr['scan_count'] ?></span></td>
                            <td style="color:var(--text-secondary);font-size:.875rem"><?= date('d M Y', strtotime($qr['created_at'])) ?></td>
                            <td><a href="<?= APP_URL ?>/analytics/qr-detail.php?id=<?= $qr['id'] ?>" class="btn btn-secondary btn-sm">View Analytics →</a></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<script>
const COLORS = ['#7c3aed','#a855f7','#3b82f6','#10b981','#f59e0b','#ef4444','#ec4899','#06b6d4'];
const chartDefaults = { plugins:{ legend:{ labels:{ color:'#9090b0', font:{size:12} } } }, scales:{ x:{ ticks:{color:'#9090b0'}, grid:{color:'#2a2a3a'} }, y:{ ticks:{color:'#9090b0'}, grid:{color:'#2a2a3a'} } } };

// Trend line chart
new Chart(document.getElementById('trendChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode(array_column($trendData, 'date')) ?>.map(d => d.slice(5)),
        datasets:[{ label:'Scans', data: <?= json_encode(array_column($trendData, 'count')) ?>, borderColor:'#7c3aed', backgroundColor:'rgba(124,58,237,.1)', fill:true, tension:.4, pointRadius:0, borderWidth:2 }]
    },
    options: { ...chartDefaults, responsive:true }
});

// Bar chart per QR
<?php if (!empty($myQRs)): ?>
new Chart(document.getElementById('barChart'), {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_map(fn($q) => substr($q['title'],0,15), $myQRs)) ?>,
        datasets:[{ label:'Scans', data: <?= json_encode(array_column($myQRs,'scan_count')) ?>, backgroundColor: <?= json_encode(array_slice(array_values(['#7c3aed','#a855f7','#3b82f6','#10b981','#f59e0b']), 0, count($myQRs))) ?>, borderRadius:4 }]
    },
    options: { ...chartDefaults, responsive:true }
});
<?php endif; ?>

// Pie charts
function makePie(id, data) {
    const labels = data.map(d => d[0]);
    const values = data.map(d => d[1]);
    if (!labels.length) return;
    new Chart(document.getElementById(id), {
        type:'doughnut',
        data:{ labels, datasets:[{ data:values, backgroundColor:COLORS }] },
        options:{ plugins:{ legend:{ position:'bottom', labels:{ color:'#9090b0', font:{size:11}, padding:8 } } }, responsive:true }
    });
}
makePie('deviceChart',  <?= json_encode(array_map(fn($r)=>[$r['device'],(int)$r['cnt']], $deviceStats)) ?>);
makePie('browserChart', <?= json_encode(array_map(fn($r)=>[$r['browser'],(int)$r['cnt']], $browserStats)) ?>);
makePie('osChart',      <?= json_encode(array_map(fn($r)=>[$r['os'],(int)$r['cnt']], $osStats)) ?>);
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
