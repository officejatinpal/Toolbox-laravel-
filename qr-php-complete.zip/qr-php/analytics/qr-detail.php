<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth-check.php';
requireLogin();

$user = getCurrentUser();
$db   = getDB();
$id   = intval($_GET['id'] ?? 0);

$stmt = $db->prepare("SELECT * FROM qr_codes WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user['id']]);
$qr = $stmt->fetch();
if (!$qr) { header('Location: ' . APP_URL . '/analytics/index.php'); exit; }

// 30-day trend
$trend = $db->prepare("SELECT DATE(scanned_at) as d, COUNT(*) as cnt FROM scan_history WHERE qr_id=? AND scanned_at >= DATE_SUB(NOW(),INTERVAL 30 DAY) GROUP BY DATE(scanned_at) ORDER BY d");
$trend->execute([$id]); $trendRaw = $trend->fetchAll();
$trendMap = []; foreach ($trendRaw as $r) $trendMap[$r['d']] = (int)$r['cnt'];
$trendData = [];
for ($i=29; $i>=0; $i--) { $d=date('Y-m-d',strtotime("-$i days")); $trendData[]=[$d,$trendMap[$d]??0]; }

// Hourly
$hourly = $db->prepare("SELECT HOUR(scanned_at) as h, COUNT(*) as cnt FROM scan_history WHERE qr_id=? GROUP BY HOUR(scanned_at)");
$hourly->execute([$id]); $hourlyRaw = $hourly->fetchAll();
$hourlyMap = []; foreach ($hourlyRaw as $r) $hourlyMap[(int)$r['h']] = (int)$r['cnt'];
$hourlyData = []; for ($h=0; $h<24; $h++) $hourlyData[] = [(string)$h.':00', $hourlyMap[$h]??0];

// Device/Browser/OS
function getStats($db, $qr_id, $col) {
    $s = $db->prepare("SELECT $col as label, COUNT(*) as cnt FROM scan_history WHERE qr_id=? GROUP BY $col ORDER BY cnt DESC");
    $s->execute([$qr_id]); return $s->fetchAll();
}
$deviceStats  = getStats($db, $id, 'device');
$browserStats = getStats($db, $id, 'browser');
$osStats      = getStats($db, $id, 'os');

// Today/Week
$today = $db->prepare("SELECT COUNT(*) FROM scan_history WHERE qr_id=? AND DATE(scanned_at)=CURDATE()");
$today->execute([$id]); $scansToday = $today->fetchColumn();
$week  = $db->prepare("SELECT COUNT(*) FROM scan_history WHERE qr_id=? AND scanned_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)");
$week->execute([$id]); $scansWeek = $week->fetchColumn();

// Recent history
$hist = $db->prepare("SELECT scanned_at, device, browser, os, ip_address FROM scan_history WHERE qr_id=? ORDER BY scanned_at DESC LIMIT 50");
$hist->execute([$id]); $history = $hist->fetchAll();

// Pagination
$page    = max(1, intval($_GET['page'] ?? 1));
$perPage = 10;
$total   = count($history);
$pages   = ceil($total / $perPage);
$paged   = array_slice($history, ($page-1)*$perPage, $perPage);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($qr['title']) ?> Analytics — QRCraft</title>
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/main.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
</head>
<body>
<?php require_once __DIR__ . '/../includes/navbar.php'; ?>
<div class="dashboard-layout">
    <aside class="sidebar">
        <div class="sidebar-section">
            <div class="sidebar-label">Navigation</div>
            <a href="<?= APP_URL ?>/dashboard/index.php" class="sidebar-item"><span class="item-icon">⬛</span> My QR Codes</a>
            <a href="<?= APP_URL ?>/dashboard/create-qr.php" class="sidebar-item"><span class="item-icon">➕</span> Create QR</a>
            <a href="<?= APP_URL ?>/analytics/index.php" class="sidebar-item active"><span class="item-icon">📊</span> Analytics</a>
        </div>
    </aside>
    <main class="dashboard-content">
        <div class="page-header">
            <div>
                <a href="<?= APP_URL ?>/analytics/index.php" class="btn btn-secondary btn-sm" style="margin-bottom:8px">← Back</a>
                <h1 class="page-title"><?= htmlspecialchars($qr['title']) ?></h1>
                <p class="page-subtitle"><?= strtoupper($qr['type']) ?> • Created <?= date('d M Y', strtotime($qr['created_at'])) ?></p>
            </div>
            <?php if ($qr['qr_image']): ?>
                <img src="<?= $qr['qr_image'] ?>" style="width:72px;height:72px;background:white;padding:4px;border-radius:8px">
            <?php endif; ?>
        </div>

        <div class="stats-grid" style="margin-bottom:1.5rem">
            <div class="stat-card"><div class="stat-label">Total Scans</div><div class="stat-value" style="color:var(--accent)"><?= $qr['scan_count'] ?></div></div>
            <div class="stat-card"><div class="stat-label">Scans Today</div><div class="stat-value" style="color:var(--green)"><?= $scansToday ?></div></div>
            <div class="stat-card"><div class="stat-label">This Week</div><div class="stat-value" style="color:var(--yellow)"><?= $scansWeek ?></div></div>
        </div>

        <div class="card" style="margin-bottom:1.5rem">
            <div class="card-header"><span class="card-title">📈 Scan Trend — Last 30 Days</span></div>
            <div class="card-body"><canvas id="trendChart" height="80"></canvas></div>
        </div>

        <div class="card" style="margin-bottom:1.5rem">
            <div class="card-header"><span class="card-title">⏰ Scans by Hour of Day</span></div>
            <div class="card-body"><canvas id="hourChart" height="80"></canvas></div>
        </div>

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:1.25rem;margin-bottom:1.5rem">
            <div class="card"><div class="card-header"><span class="card-title">📱 Device</span></div><div class="card-body"><canvas id="devChart" height="120"></canvas></div></div>
            <div class="card"><div class="card-header"><span class="card-title">🌐 Browser</span></div><div class="card-body"><canvas id="brChart" height="120"></canvas></div></div>
            <div class="card"><div class="card-header"><span class="card-title">💻 OS</span></div><div class="card-body"><canvas id="osChart" height="120"></canvas></div></div>
        </div>

        <div class="card">
            <div class="card-header"><span class="card-title">🕓 Recent Scan History</span><span style="font-size:.8rem;color:var(--text-muted)"><?= $total ?> records</span></div>
            <?php if (empty($history)): ?>
                <div class="empty-state" style="padding:2rem"><div class="empty-icon" style="font-size:2rem">📭</div><p>No scans yet</p></div>
            <?php else: ?>
                <div style="overflow-x:auto">
                    <table class="admin-table">
                        <thead><tr><th>#</th><th>Date & Time</th><th>Device</th><th>Browser</th><th>OS</th><th>IP</th></tr></thead>
                        <tbody>
                        <?php foreach ($paged as $i => $s): ?>
                            <tr>
                                <td style="font-family:var(--font-mono);color:var(--text-muted);font-size:.8rem"><?= ($page-1)*$perPage+$i+1 ?></td>
                                <td>
                                    <div style="font-weight:600;font-size:.875rem"><?= date('d M Y', strtotime($s['scanned_at'])) ?></div>
                                    <div style="font-size:.75rem;color:var(--text-muted)"><?= date('h:i A', strtotime($s['scanned_at'])) ?></div>
                                </td>
                                <td><?= $s['device']==='Mobile'?'📱':($s['device']==='Tablet'?'📟':'💻') ?> <?= htmlspecialchars($s['device']) ?></td>
                                <td><span class="badge badge-blue" style="font-size:.7rem"><?= htmlspecialchars($s['browser']) ?></span></td>
                                <td style="font-size:.875rem;color:var(--text-secondary)"><?= htmlspecialchars($s['os']) ?></td>
                                <td style="font-family:var(--font-mono);font-size:.8rem;color:var(--text-muted)"><?= htmlspecialchars(preg_replace('/\.\d+$/', '.***', $s['ip_address'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($pages > 1): ?>
                    <div style="display:flex;align-items:center;justify-content:center;gap:8px;padding:1rem;border-top:1px solid var(--border)">
                        <?php if ($page > 1): ?><a href="?id=<?=$id?>&page=<?=$page-1?>" class="btn btn-secondary btn-sm">← Prev</a><?php endif; ?>
                        <span style="font-size:.875rem;color:var(--text-secondary)">Page <?=$page?> of <?=$pages?></span>
                        <?php if ($page < $pages): ?><a href="?id=<?=$id?>&page=<?=$page+1?>" class="btn btn-secondary btn-sm">Next →</a><?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </main>
</div>

<script>
const COLORS=['#7c3aed','#a855f7','#3b82f6','#10b981','#f59e0b','#ef4444'];
const opts = { plugins:{legend:{labels:{color:'#9090b0',font:{size:12}}}}, scales:{x:{ticks:{color:'#9090b0'},grid:{color:'#2a2a3a'}},y:{ticks:{color:'#9090b0'},grid:{color:'#2a2a3a'}}}, responsive:true };
const pieOpts = { plugins:{legend:{position:'bottom',labels:{color:'#9090b0',font:{size:11},padding:8}}}, responsive:true };

new Chart(document.getElementById('trendChart'),{type:'line',data:{labels:<?= json_encode(array_column($trendData,0)) ?>.map(d=>d.slice(5)),datasets:[{label:'Scans',data:<?= json_encode(array_column($trendData,1)) ?>,borderColor:'#7c3aed',backgroundColor:'rgba(124,58,237,.1)',fill:true,tension:.4,pointRadius:0,borderWidth:2}]},options:opts});

const hMax=Math.max(...<?= json_encode(array_column($hourlyData,1)) ?>);
new Chart(document.getElementById('hourChart'),{type:'bar',data:{labels:<?= json_encode(array_column($hourlyData,0)) ?>,datasets:[{label:'Scans',data:<?= json_encode(array_column($hourlyData,1)) ?>,backgroundColor:<?= json_encode(array_column($hourlyData,1)) ?>.map(v=>v===hMax?'#7c3aed':'#3b3b55'),borderRadius:3}]},options:opts});

function pie(id,data){if(!data.length)return;new Chart(document.getElementById(id),{type:'doughnut',data:{labels:data.map(d=>d[0]),datasets:[{data:data.map(d=>d[1]),backgroundColor:COLORS}]},options:pieOpts});}
pie('devChart',<?= json_encode(array_map(fn($r)=>[$r['label'],(int)$r['cnt']],$deviceStats)) ?>);
pie('brChart', <?= json_encode(array_map(fn($r)=>[$r['label'],(int)$r['cnt']],$browserStats)) ?>);
pie('osChart', <?= json_encode(array_map(fn($r)=>[$r['label'],(int)$r['cnt']],$osStats)) ?>);
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
