<?php
require_once __DIR__ . '/../config/db.php';
if (!empty($_SESSION['user_id'])) {
    header('Location: ' . APP_URL . '/dashboard/index.php'); exit;
}
$error = '';
$urlError = $_GET['error'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        $error = 'Email and password are required';
    } else {
        $db   = getDB();
        $stmt = $db->prepare("SELECT id, name, email, password, role, is_banned, ban_reason FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password'])) {
            $error = 'Invalid email or password';
        } elseif ($user['is_banned']) {
            $error = 'Account banned: ' . $user['ban_reason'];
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name']    = $user['name'];
            $_SESSION['email']   = $user['email'];
            $_SESSION['role']    = $user['role'];
            $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")->execute([$user['id']]);
            header('Location: ' . APP_URL . '/dashboard/index.php'); exit;
        }
    }
}
$pageTitle = 'Login';
?>
<?php require_once __DIR__ . '/../config/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — QRCraft</title>
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/main.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="auth-logo">
            <div class="logo-big">⬛</div>
            <h1 class="auth-title">Welcome back</h1>
            <p class="auth-subtitle">Login to your QRCraft account</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($urlError): ?>
            <div class="alert alert-error">⚠️ <?= htmlspecialchars($urlError) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-input" placeholder="you@example.com"
                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required autofocus>
            </div>
            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-input" placeholder="••••••••" required>
            </div>
            <div style="text-align:right;margin-bottom:1.25rem;margin-top:-0.5rem">
                <a href="<?= APP_URL ?>/auth/forgot-password.php" style="font-size:.85rem;color:var(--accent);text-decoration:none">Forgot password?</a>
            </div>
            <button type="submit" class="btn btn-primary btn-full btn-lg">Login →</button>
        </form>

        <div class="auth-footer">
            Don't have an account? <a href="<?= APP_URL ?>/auth/signup.php">Sign up free</a>
        </div>
    </div>
</div>
</body>
</html>
