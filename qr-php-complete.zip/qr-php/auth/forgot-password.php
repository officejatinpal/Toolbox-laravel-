<?php
require_once __DIR__ . '/../config/db.php';
$message = '';
$type    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    if (!$email) {
        $message = 'Email is required'; $type = 'error';
    } else {
        $db   = getDB();
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $message = 'Password reset instructions sent to your email (feature coming soon)';
            $type    = 'success';
        } else {
            $message = 'No account found with this email'; $type = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password — QRCraft</title>
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/main.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="auth-logo">
            <div class="logo-big">🔑</div>
            <h1 class="auth-title">Forgot Password</h1>
            <p class="auth-subtitle">Enter your email to reset password</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?= $type === 'success' ? 'success' : 'error' ?>"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-input" placeholder="you@example.com" required autofocus>
            </div>
            <button type="submit" class="btn btn-primary btn-full btn-lg">Send Reset Link</button>
        </form>
        <div class="auth-footer"><a href="<?= APP_URL ?>/auth/login.php">← Back to login</a></div>
    </div>
</div>
</body>
</html>
