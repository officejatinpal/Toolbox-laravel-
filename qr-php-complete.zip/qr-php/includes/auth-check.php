<?php
require_once __DIR__ . '/../config/db.php';

function requireLogin() {
    if (empty($_SESSION['user_id'])) {
        header('Location: ' . APP_URL . '/auth/login.php');
        exit;
    }
    // Check if banned
    $db = getDB();
    $stmt = $db->prepare("SELECT is_banned, ban_reason FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    if ($user && $user['is_banned']) {
        session_destroy();
        header('Location: ' . APP_URL . '/auth/login.php?error=' . urlencode('Account banned: ' . $user['ban_reason']));
        exit;
    }
}

function getCurrentUser() {
    if (empty($_SESSION['user_id'])) return null;
    $db = getDB();
    $stmt = $db->prepare("SELECT id, name, email, role, qr_count, qr_limit, created_at FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

function isAdmin() {
    return !empty($_SESSION['role']) && $_SESSION['role'] === 'admin';
}
