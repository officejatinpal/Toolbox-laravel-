<?php
function parseUserAgent($ua = '') {
    $ua = strtolower($ua);

    // Device
    $device = 'Desktop';
    if (preg_match('/ipad|tablet|playbook|silk/', $ua)) {
        $device = 'Tablet';
    } elseif (preg_match('/mobile|iphone|ipod|android.*mobile|blackberry|windows phone|opera mini/', $ua)) {
        $device = 'Mobile';
    }

    // Browser
    $browser = 'Unknown';
    if (preg_match('/edg\//', $ua)) $browser = 'Edge';
    elseif (preg_match('/opr\/|opera/', $ua)) $browser = 'Opera';
    elseif (preg_match('/chrome\//', $ua) && !preg_match('/chromium/', $ua)) $browser = 'Chrome';
    elseif (preg_match('/firefox\//', $ua)) $browser = 'Firefox';
    elseif (preg_match('/safari\//', $ua) && !preg_match('/chrome/', $ua)) $browser = 'Safari';
    elseif (preg_match('/msie|trident/', $ua)) $browser = 'IE';

    // OS
    $os = 'Unknown';
    if (preg_match('/windows nt 10/', $ua)) $os = 'Windows 10';
    elseif (preg_match('/windows nt 6\.3/', $ua)) $os = 'Windows 8.1';
    elseif (preg_match('/windows nt 6\.1/', $ua)) $os = 'Windows 7';
    elseif (preg_match('/windows/', $ua)) $os = 'Windows';
    elseif (preg_match('/android/', $ua)) {
        preg_match('/android\s*([\d.]+)/', $ua, $m);
        $os = isset($m[1]) ? 'Android ' . $m[1] : 'Android';
    } elseif (preg_match('/iphone|ipad|ipod/', $ua)) $os = 'iOS';
    elseif (preg_match('/mac os x/', $ua)) $os = 'macOS';
    elseif (preg_match('/linux/', $ua)) $os = 'Linux';

    return ['device' => $device, 'browser' => $browser, 'os' => $os];
}

function getClientIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    return $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
}
