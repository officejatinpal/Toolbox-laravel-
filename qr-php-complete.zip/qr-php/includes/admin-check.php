<?php
require_once __DIR__ . '/auth-check.php';

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: ' . APP_URL . '/dashboard/index.php');
        exit;
    }
}
