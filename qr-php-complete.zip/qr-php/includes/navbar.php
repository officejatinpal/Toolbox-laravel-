<?php $currentUser = getCurrentUser(); ?>
<nav class="navbar">
    <a href="<?= APP_URL ?>/index.php" class="navbar-brand">
        <div class="logo-icon">⬛</div>
        QRCraft
    </a>
    <div class="navbar-nav">
        <?php if ($currentUser): ?>
            <a href="<?= APP_URL ?>/dashboard/index.php" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/dashboard') !== false ? 'active' : '' ?>">Dashboard</a>
            <a href="<?= APP_URL ?>/analytics/index.php" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/analytics') !== false ? 'active' : '' ?>">Analytics</a>
            <?php if ($currentUser['role'] === 'admin'): ?>
                <a href="<?= APP_URL ?>/admin/index.php" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin') !== false ? 'active' : '' ?>">Admin</a>
            <?php endif; ?>
            <div class="nav-user">
                <div class="avatar"><?= strtoupper(substr($currentUser['name'], 0, 1)) ?></div>
                <span><?= htmlspecialchars($currentUser['name']) ?></span>
            </div>
            <a href="<?= APP_URL ?>/auth/logout.php" class="btn btn-secondary" style="padding:7px 14px;font-size:.875rem">Logout</a>
        <?php else: ?>
            <a href="<?= APP_URL ?>/index.php" class="nav-link">Home</a>
            <a href="<?= APP_URL ?>/auth/login.php" class="nav-link">Login</a>
            <a href="<?= APP_URL ?>/auth/signup.php" class="btn btn-primary" style="padding:8px 18px;font-size:.875rem">Get Started</a>
        <?php endif; ?>
    </div>
</nav>
