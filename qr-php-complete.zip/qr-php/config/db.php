<?php
// ─── DATABASE CONFIGURATION ────────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // apna MySQL username
define('DB_PASS', '');            // apna MySQL password
define('DB_NAME', 'qrcraft');
define('DB_CHARSET', 'utf8mb4');

// ─── APP CONFIGURATION ────────────────────────────────────────────────────
define('APP_NAME', 'QRCraft');
define('APP_URL', 'http://localhost/qr-php');  // apna local URL
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('UPLOAD_URL', APP_URL . '/uploads/');
define('QR_FREE_LIMIT', 3);
define('MAX_IMAGE_SIZE', 10 * 1024 * 1024);   // 10MB
define('MAX_VIDEO_SIZE', 50 * 1024 * 1024);   // 50MB

// ─── DATABASE CONNECTION ──────────────────────────────────────────────────
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
