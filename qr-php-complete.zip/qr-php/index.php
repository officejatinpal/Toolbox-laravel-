<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth-check.php';
$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QRCraft — QR Code Generator</title>
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/main.css">
</head>
<body>
<?php require_once __DIR__ . '/includes/navbar.php'; ?>

<!-- Hero -->
<div class="home-hero">
    <div class="hero-badge">✨ Free QR Code Generator</div>
    <h1 class="hero-title">
        Create <span class="gradient-text">Powerful QR Codes</span><br>in Seconds
    </h1>
    <p class="hero-subtitle">
        Generate QR codes for URLs, images, videos, text, and vCards.
        Track scans, manage all your codes in one place.
    </p>
    <div class="hero-actions">
        <?php if ($currentUser): ?>
            <a href="<?= APP_URL ?>/dashboard/index.php" class="btn btn-primary btn-lg">Open Dashboard →</a>
        <?php else: ?>
            <a href="<?= APP_URL ?>/auth/signup.php" class="btn btn-primary btn-lg">Start for Free →</a>
            <a href="<?= APP_URL ?>/auth/login.php" class="btn btn-secondary btn-lg">Login</a>
        <?php endif; ?>
    </div>
    <div style="margin-top:2rem;display:flex;justify-content:center;gap:1.5rem;flex-wrap:wrap">
        <?php foreach(['✅ 3 Free QR Codes','✅ All QR Types','✅ Scan Tracking','✅ Download PNG'] as $f): ?>
            <span style="font-size:.875rem;color:var(--text-secondary)"><?= $f ?></span>
        <?php endforeach; ?>
    </div>
</div>

<!-- Features -->
<div style="padding:0 1rem 4rem">
    <h2 style="text-align:center;margin-bottom:2rem;font-size:1.75rem;font-weight:700">
        Everything you need to <span style="color:var(--accent)">go QR</span>
    </h2>
    <div class="features-grid">
        <?php
        $features = [
            ['🔗','URL QR Codes','Turn any link into a scannable QR instantly'],
            ['🖼️','Image QR Codes','Share photos and graphics via QR code'],
            ['🎬','Video QR Codes','Link videos directly to your QR code'],
            ['👤','vCard / Profile','Share your contact as a digital business card'],
            ['📝','Text QR Codes','Encode any plain text into a QR code'],
            ['📊','Scan Analytics','Track every scan with detailed statistics'],
        ];
        foreach ($features as $f): ?>
            <div class="feature-card">
                <div class="feature-icon"><?= $f[0] ?></div>
                <div class="feature-title"><?= $f[1] ?></div>
                <div class="feature-desc"><?= $f[2] ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php if (!$currentUser): ?>
<div style="text-align:center;padding:3rem 2rem 5rem;background:radial-gradient(ellipse at 50% 50%,rgba(124,58,237,.12) 0%,transparent 60%)">
    <h2 style="font-size:2rem;font-weight:700;margin-bottom:1rem">Ready to get started?</h2>
    <p style="color:var(--text-secondary);margin-bottom:1.5rem">Create your free account and generate up to 3 QR codes.</p>
    <a href="<?= APP_URL ?>/auth/signup.php" class="btn btn-primary btn-lg">Create Free Account →</a>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
</body>
</html>
