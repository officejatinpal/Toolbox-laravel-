<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth-check.php';
header('Content-Type: application/json');

requireLogin();
$user = getCurrentUser();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']); exit;
}

if ($user['qr_count'] >= $user['qr_limit'] && $user['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => "Free limit reached ({$user['qr_limit']} QRs max)"]); exit;
}

$title    = trim($_POST['title'] ?? '');
$type     = $_POST['type'] ?? '';
$content  = trim($_POST['content'] ?? '');
$qrImage  = $_POST['qr_image'] ?? '';

if (!$title || !$type) {
    echo json_encode(['success' => false, 'message' => 'Title and type are required']); exit;
}

$allowedTypes = ['url','text','image','video','profile'];
if (!in_array($type, $allowedTypes)) {
    echo json_encode(['success' => false, 'message' => 'Invalid QR type']); exit;
}

$fileUrl = ''; $fileName = ''; $fileSize = 0; $profileData = '';

// Handle file upload
if (in_array($type, ['image','video']) && isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
    $file     = $_FILES['file'];
    $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed  = $type === 'image' ? ['jpg','jpeg','png','gif','webp'] : ['mp4','avi','mov','mkv','webm'];
    $maxSize  = $type === 'image' ? MAX_IMAGE_SIZE : MAX_VIDEO_SIZE;

    if (!in_array($ext, $allowed)) {
        echo json_encode(['success' => false, 'message' => 'Invalid file type']); exit;
    }
    if ($file['size'] > $maxSize) {
        echo json_encode(['success' => false, 'message' => 'File too large']); exit;
    }

    $subDir  = $type === 'image' ? 'images' : 'videos';
    $newName = time() . '_' . mt_rand(1000,9999) . '.' . $ext;
    $destDir = UPLOAD_PATH . $subDir . '/';
    if (!is_dir($destDir)) mkdir($destDir, 0755, true);

    if (move_uploaded_file($file['tmp_name'], $destDir . $newName)) {
        $fileUrl  = UPLOAD_URL . $subDir . '/' . $newName;
        $fileName = $file['name'];
        $fileSize = $file['size'];
        $content  = $fileUrl;
    } else {
        echo json_encode(['success' => false, 'message' => 'File upload failed']); exit;
    }
} elseif ($type === 'profile') {
    $pd = [
        'firstName'    => $_POST['profile_first']   ?? '',
        'lastName'     => $_POST['profile_last']    ?? '',
        'phone'        => $_POST['profile_phone']   ?? '',
        'email'        => $_POST['profile_email']   ?? '',
        'organization' => $_POST['profile_org']     ?? '',
        'website'      => $_POST['profile_website'] ?? '',
        'address'      => $_POST['profile_address'] ?? '',
    ];
    $profileData = json_encode($pd);
    $content = "BEGIN:VCARD\nVERSION:3.0\nFN:{$pd['firstName']} {$pd['lastName']}\nTEL:{$pd['phone']}\nEMAIL:{$pd['email']}\nORG:{$pd['organization']}\nURL:{$pd['website']}\nADR:{$pd['address']}\nEND:VCARD";
}

$db   = getDB();
$stmt = $db->prepare("INSERT INTO qr_codes (user_id, title, type, content, file_url, file_name, file_size, profile_data, qr_image) VALUES (?,?,?,?,?,?,?,?,?)");
$stmt->execute([$user['id'], $title, $type, $content, $fileUrl, $fileName, $fileSize, $profileData, $qrImage]);

$db->prepare("UPDATE users SET qr_count = qr_count + 1 WHERE id = ?")->execute([$user['id']]);

echo json_encode(['success' => true, 'message' => 'QR created successfully', 'id' => $db->lastInsertId()]);
