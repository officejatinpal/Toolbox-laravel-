<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/admin-check.php';
requireAdmin();

$id     = intval($_POST['user_id'] ?? 0);
$reason = trim($_POST['reason'] ?? 'Violated terms of service');
$db     = getDB();

$stmt = $db->prepare("SELECT role FROM users WHERE id=?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user || $user['role'] === 'admin') {
    header('Location: ' . APP_URL . '/admin/index.php?tab=users&err=Cannot+ban+this+user'); exit;
}

$db->prepare("UPDATE users SET is_banned=1, ban_reason=? WHERE id=?")->execute([$reason, $id]);
header('Location: ' . APP_URL . '/admin/index.php?tab=users&msg=User+banned+successfully');
exit;
