<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/admin-check.php';
requireAdmin();
$id = intval($_GET['id'] ?? 0);
getDB()->prepare("UPDATE users SET is_banned=0, ban_reason='' WHERE id=?")->execute([$id]);
header('Location: ' . APP_URL . '/admin/index.php?tab=users&msg=User+unbanned+successfully');
exit;
