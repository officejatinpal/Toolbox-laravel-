<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/admin-check.php';
requireAdmin();

$id = intval($_GET['id'] ?? 0);
$db = getDB();
$stmt = $db->prepare("SELECT role FROM users WHERE id=?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user || $user['role'] === 'admin') {
    header('Location: ' . APP_URL . '/admin/index.php?tab=users&err=Cannot+delete+this+user'); exit;
}

// Delete uploaded files
$files = $db->prepare("SELECT file_url FROM qr_codes WHERE user_id=? AND file_url != ''");
$files->execute([$id]);
foreach ($files->fetchAll() as $f) {
    $path = str_replace(UPLOAD_URL, UPLOAD_PATH, $f['file_url']);
    if (file_exists($path)) unlink($path);
}

$db->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
header('Location: ' . APP_URL . '/admin/index.php?tab=users&msg=User+deleted+successfully');
exit;
