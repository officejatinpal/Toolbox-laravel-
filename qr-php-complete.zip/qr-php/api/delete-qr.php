<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth-check.php';
requireLogin();

$id   = intval($_GET['id'] ?? 0);
$user = getCurrentUser();
$db   = getDB();

$stmt = $db->prepare("SELECT * FROM qr_codes WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user['id']]);
$qr = $stmt->fetch();

if (!$qr) {
    header('Location: ' . APP_URL . '/dashboard/index.php?error=QR+not+found'); exit;
}

// Delete file if exists
if ($qr['file_url']) {
    $localPath = str_replace(UPLOAD_URL, UPLOAD_PATH, $qr['file_url']);
    if (file_exists($localPath)) unlink($localPath);
}

$db->prepare("DELETE FROM qr_codes WHERE id = ? AND user_id = ?")->execute([$id, $user['id']]);
$db->prepare("UPDATE users SET qr_count = GREATEST(0, qr_count - 1) WHERE id = ?")->execute([$user['id']]);

header('Location: ' . APP_URL . '/dashboard/index.php?msg=QR+deleted+successfully');
exit;
