<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/ua-parser.php';
header('Content-Type: application/json');

$id = intval($_GET['id'] ?? 0);
if (!$id) { echo json_encode(['success' => false]); exit; }

$db   = getDB();
$stmt = $db->prepare("SELECT id, content FROM qr_codes WHERE id = ? AND is_active = 1");
$stmt->execute([$id]);
$qr = $stmt->fetch();

if (!$qr) { echo json_encode(['success' => false, 'message' => 'QR not found']); exit; }

$ua      = $_SERVER['HTTP_USER_AGENT'] ?? '';
$parsed  = parseUserAgent($ua);
$ip      = getClientIP();

$db->prepare("UPDATE qr_codes SET scan_count = scan_count + 1 WHERE id = ?")->execute([$id]);
$db->prepare("INSERT INTO scan_history (qr_id, ip_address, user_agent, device, browser, os) VALUES (?,?,?,?,?,?)")
   ->execute([$id, $ip, $ua, $parsed['device'], $parsed['browser'], $parsed['os']]);

echo json_encode(['success' => true, 'content' => $qr['content']]);
