<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/admin-check.php';
requireAdmin();

$db = getDB();
$users = $db->query("SELECT name,email,qr_count,is_banned,ban_reason,created_at FROM users WHERE role='user' ORDER BY created_at DESC")->fetchAll();
$qrs   = $db->query("SELECT q.title,q.type,q.scan_count,q.created_at,u.name as uname,u.email as uemail FROM qr_codes q JOIN users u ON q.user_id=u.id ORDER BY q.created_at DESC")->fetchAll();

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="qrcraft-report-' . date('Y-m-d') . '.csv"');

$out = fopen('php://output', 'w');

fputcsv($out, ['=== USERS REPORT ===']);
fputcsv($out, ['Name','Email','QR Count','Status','Ban Reason','Joined']);
foreach ($users as $u) {
    fputcsv($out, [$u['name'], $u['email'], $u['qr_count'], $u['is_banned']?'Banned':'Active', $u['ban_reason'], $u['created_at']]);
}

fputcsv($out, []);
fputcsv($out, ['=== QR CODES REPORT ===']);
fputcsv($out, ['Title','Type','Owner','Owner Email','Scans','Created']);
foreach ($qrs as $q) {
    fputcsv($out, [$q['title'], $q['type'], $q['uname'], $q['uemail'], $q['scan_count'], $q['created_at']]);
}

fclose($out);
exit;
