<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/admin-check.php';
requireAdmin();

$db     = getDB();
$search = trim($_GET['search'] ?? '');
$tab    = $_GET['tab'] ?? 'analytics';

// Analytics data
$totalUsers  = $db->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
$bannedUsers = $db->query("SELECT COUNT(*) FROM users WHERE is_banned=1")->fetchColumn();
$totalQRs    = $db->query("SELECT COUNT(*) FROM qr_codes")->fetchColumn();
$totalScans  = $db->query("SELECT COALESCE(SUM(scan_count),0) FROM qr_codes")->fetchColumn();

// QR by type
$qrByType = $db->query("SELECT type, COUNT(*) as cnt FROM qr_codes GROUP BY type ORDER BY cnt DESC")->fetchAll();

// Top QRs
$topQRs = $db->query("SELECT q.*, u.name as uname, u.email as uemail FROM qr_codes q JOIN users u ON q.user_id=u.id ORDER BY q.scan_count DESC LIMIT 5")->fetchAll();

// Recent users
$recentUsers = $db->query("SELECT id,name,email,qr_count,is_banned,created_at FROM users WHERE role='user' ORDER BY created_at DESC LIMIT 5")->fetchAll();

// User growth last 6 months
$growth = $db->query("SELECT DATE_FORMAT(created_at,'%Y-%m') as m, COUNT(*) as cnt FROM users WHERE created_at >= DATE_SUB(NOW(),INTERVAL 6 MONTH) GROUP BY m ORDER BY m")->fetchAll();

// Users list
if ($search) {
    $s    = "%$search%";
    $stmt = $db->prepare("SELECT * FROM users WHERE role='user' AND (name LIKE ? OR email LIKE ?) ORDER BY created_at DESC");
    $stmt->execute([$s, $s]);
} else {
    $stmt = $db->query("SELECT * FROM users WHERE role='user' ORDER BY created_at DESC");
}
$users = $stmt->fetchAll();

// Handle actions
$msg = $_GET['msg'] ?? '';
$err = $_GET['err'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel — QRCraft</title>
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/main.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
</head>
<body>
<?php require_once __DIR__ . '/../includes/navbar.php'; ?>
<div style="padding:2rem;max-width:1200px;margin:0 auto">
    <div class="page-header">
        <div>
            <h1 class="page-title">⚙️ Admin Panel</h1>
            <p class="page-subtitle">Manage users, QR codes, and view analytics</p>
        </div>
        <a href="<?= APP_URL ?>/admin/download-report.php" class="btn btn-secondary">⬇ Download Report</a>
    </div>

    <?php if ($msg): ?><div class="alert alert-success" style="margin-bottom:1rem">✅ <?= htmlspecialchars($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="alert alert-error" style="margin-bottom:1rem">⚠️ <?= htmlspecialchars($err) ?></div><?php endif; ?>

    <div class="tabs">
        <a href="?tab=analytics" class="tab-btn <?= $tab==='analytics'?'active':'' ?>">📊 Analytics</a>
        <a href="?tab=users" class="tab-btn <?= $tab==='users'?'active':'' ?>">👥 Users</a>
    </div>

    <?php if ($tab === 'analytics'): ?>
        <!-- Stats -->
        <div class="stats-grid" style="margin-bottom:1.5rem">
            <div class="stat-card"><div class="stat-label">Total Users</div><div class="stat-value" style="color:var(--accent)"><?= $totalUsers ?></div></div>
            <div class="stat-card"><div class="stat-label">Banned Users</div><div class="stat-value" style="color:var(--red)"><?= $bannedUsers ?></div></div>
            <div class="stat-card"><div class="stat-label">Total QR Codes</div><div class="stat-value" style="color:var(--green)"><?= $totalQRs ?></div></div>
            <div class="stat-card"><div class="stat-label">Total Scans</div><div class="stat-value" style="color:var(--yellow)"><?= $totalScans ?></div></div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-bottom:1.5rem">
            <!-- QR by Type -->
            <div class="card">
                <div class="card-header"><span class="card-title">QR Codes by Type</span></div>
                <div class="card-body">
                    <?php foreach ($qrByType as $t): $max = max(array_column($qrByType,'cnt')) ?: 1; ?>
                        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
                            <span style="min-width:80px;font-size:.875rem"><?= strtoupper($t['type']) ?></span>
                            <div style="flex:1;height:8px;background:var(--border);border-radius:4px;overflow:hidden">
                                <div style="height:100%;background:linear-gradient(90deg,var(--accent),#a855f7);border-radius:4px;width:<?= ($t['cnt']/$max)*100 ?>%"></div>
                            </div>
                            <span style="font-family:var(--font-mono);font-weight:700;min-width:24px"><?= $t['cnt'] ?></span>
                        </div>
                    <?php endforeach; ?>
                    <?php if (empty($qrByType)): ?><p style="color:var(--text-muted);text-align:center">No data</p><?php endif; ?>
                </div>
            </div>

            <!-- Top QRs -->
            <div class="card">
                <div class="card-header"><span class="card-title">Top Scanned QRs</span></div>
                <div class="card-body">
                    <?php foreach ($topQRs as $i => $q): ?>
                        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;padding:8px;border-radius:8px;background:var(--bg-hover)">
                            <span style="font-family:var(--font-mono);font-weight:700;font-size:1.1rem;color:var(--accent);min-width:24px">#<?= $i+1 ?></span>
                            <div style="flex:1;overflow:hidden">
                                <div style="font-weight:600;font-size:.875rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($q['title']) ?></div>
                                <div style="font-size:.75rem;color:var(--text-muted)"><?= htmlspecialchars($q['uname']) ?></div>
                            </div>
                            <span class="badge badge-green"><?= $q['scan_count'] ?> scans</span>
                        </div>
                    <?php endforeach; ?>
                    <?php if (empty($topQRs)): ?><p style="color:var(--text-muted);text-align:center">No data</p><?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Recent Users -->
        <div class="card">
            <div class="card-header"><span class="card-title">Recent Users</span></div>
            <div class="admin-table-wrap">
                <table class="admin-table">
                    <thead><tr><th>User</th><th>QR Codes</th><th>Status</th><th>Joined</th></tr></thead>
                    <tbody>
                    <?php foreach ($recentUsers as $u): ?>
                        <tr>
                            <td><div class="user-cell"><div class="user-avatar"><?= strtoupper(substr($u['name'],0,1)) ?></div><div class="user-name"><?= htmlspecialchars($u['name']) ?></div></div></td>
                            <td><span style="font-family:var(--font-mono);font-weight:700"><?= $u['qr_count'] ?></span></td>
                            <td><?= $u['is_banned'] ? '<span class="badge badge-red">Banned</span>' : '<span class="badge badge-green">Active</span>' ?></td>
                            <td style="color:var(--text-secondary)"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    <?php else: // USERS TAB ?>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.25rem">
            <form method="GET" style="display:flex;align-items:center;gap:10px">
                <input type="hidden" name="tab" value="users">
                <div class="search-bar">
                    <span style="color:var(--text-muted)">🔍</span>
                    <input name="search" placeholder="Search by name or email..." value="<?= htmlspecialchars($search) ?>">
                </div>
                <button type="submit" class="btn btn-secondary btn-sm">Search</button>
                <?php if ($search): ?><a href="?tab=users" class="btn btn-secondary btn-sm">Clear</a><?php endif; ?>
            </form>
            <span style="color:var(--text-secondary);font-size:.875rem"><?= count($users) ?> users</span>
        </div>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead><tr><th>User</th><th>Email</th><th>QR Codes</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if (empty($users)): ?>
                    <tr><td colspan="6" style="text-align:center;padding:3rem;color:var(--text-muted)">No users found</td></tr>
                <?php else: foreach ($users as $u): ?>
                    <tr>
                        <td>
                            <div class="user-cell">
                                <div class="user-avatar"><?= strtoupper(substr($u['name'],0,1)) ?></div>
                                <div>
                                    <div class="user-name"><?= htmlspecialchars($u['name']) ?></div>
                                </div>
                            </div>
                        </td>
                        <td style="color:var(--text-secondary);font-size:.875rem"><?= htmlspecialchars($u['email']) ?></td>
                        <td><span style="font-family:var(--font-mono);font-weight:700"><?= $u['qr_count'] ?></span></td>
                        <td>
                            <?php if ($u['is_banned']): ?>
                                <span class="badge badge-red" title="<?= htmlspecialchars($u['ban_reason']) ?>">Banned</span>
                            <?php else: ?>
                                <span class="badge badge-green">Active</span>
                            <?php endif; ?>
                        </td>
                        <td style="color:var(--text-secondary);font-size:.875rem"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                        <td>
                            <div style="display:flex;gap:6px;flex-wrap:wrap">
                                <a href="<?= APP_URL ?>/admin/user-detail.php?id=<?= $u['id'] ?>" class="btn btn-secondary btn-sm">Details</a>
                                <?php if ($u['is_banned']): ?>
                                    <a href="<?= APP_URL ?>/api/unban-user.php?id=<?= $u['id'] ?>" class="btn btn-success btn-sm">Unban</a>
                                <?php else: ?>
                                    <button class="btn btn-danger btn-sm" onclick="showBanModal(<?= $u['id'] ?>, '<?= htmlspecialchars($u['name']) ?>')">Ban</button>
                                <?php endif; ?>
                                <a href="<?= APP_URL ?>/api/delete-user.php?id=<?= $u['id'] ?>" class="btn btn-danger btn-sm"
                                   onclick="return confirm('Delete <?= htmlspecialchars($u['name']) ?> and all their QR codes? This cannot be undone.')">🗑</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Ban Modal -->
<div id="ban-modal" class="modal-overlay" style="display:none" onclick="closeBanModal()">
    <div class="modal" onclick="event.stopPropagation()">
        <div class="modal-header">
            <span class="modal-title">🚫 Ban User</span>
            <button class="modal-close" onclick="closeBanModal()">✕</button>
        </div>
        <form method="POST" action="<?= APP_URL ?>/api/ban-user.php">
            <div class="modal-body">
                <p style="color:var(--text-secondary);margin-bottom:1rem">Ban <strong id="ban-name" style="color:var(--text-primary)"></strong>?</p>
                <input type="hidden" name="user_id" id="ban-uid">
                <div class="form-group">
                    <label class="form-label">Ban Reason</label>
                    <input type="text" name="reason" class="form-input" placeholder="Reason for ban..." required autofocus>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-danger">🚫 Ban User</button>
                <button type="button" class="btn btn-secondary" onclick="closeBanModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function showBanModal(id, name) {
    document.getElementById('ban-uid').value  = id;
    document.getElementById('ban-name').textContent = name;
    document.getElementById('ban-modal').style.display = 'flex';
}
function closeBanModal() { document.getElementById('ban-modal').style.display = 'none'; }
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
