<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/admin-check.php';
requireAdmin();

$db = getDB();
$id = intval($_GET['id'] ?? 0);
$stmt = $db->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$id]);
$user = $stmt->fetch();
if (!$user) { header('Location: ' . APP_URL . '/admin/index.php?tab=users'); exit; }

$qrs = $db->prepare("SELECT * FROM qr_codes WHERE user_id=? ORDER BY created_at DESC");
$qrs->execute([$id]); $userQRs = $qrs->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details — Admin</title>
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/main.css">
</head>
<body>
<?php require_once __DIR__ . '/../includes/navbar.php'; ?>
<div style="padding:2rem;max-width:900px;margin:0 auto">
    <a href="<?= APP_URL ?>/admin/index.php?tab=users" class="btn btn-secondary btn-sm" style="margin-bottom:1.5rem">← Back to Users</a>

    <div style="display:flex;align-items:center;gap:14px;margin-bottom:2rem;padding:1.25rem;background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-lg)">
        <div style="width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,var(--accent),#a855f7);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1.25rem">
            <?= strtoupper(substr($user['name'],0,1)) ?>
        </div>
        <div style="flex:1">
            <div style="font-weight:700;font-size:1.1rem"><?= htmlspecialchars($user['name']) ?></div>
            <div style="color:var(--text-secondary);font-size:.875rem"><?= htmlspecialchars($user['email']) ?></div>
            <div style="display:flex;gap:8px;margin-top:4px">
                <?= $user['is_banned'] ? '<span class="badge badge-red">Banned</span>' : '<span class="badge badge-green">Active</span>' ?>
                <span class="badge badge-purple"><?= $user['role'] ?></span>
            </div>
        </div>
        <div style="display:flex;gap:8px">
            <?php if ($user['role'] !== 'admin'): ?>
                <?php if ($user['is_banned']): ?>
                    <a href="<?= APP_URL ?>/api/unban-user.php?id=<?= $user['id'] ?>" class="btn btn-success btn-sm">Unban</a>
                <?php else: ?>
                    <button class="btn btn-danger btn-sm" onclick="document.getElementById('bform').style.display='block'">Ban User</button>
                <?php endif; ?>
                <a href="<?= APP_URL ?>/api/delete-user.php?id=<?= $user['id'] ?>" class="btn btn-danger btn-sm"
                   onclick="return confirm('Delete this user?')">🗑 Delete</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Ban form (hidden) -->
    <div id="bform" style="display:none;background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:1.25rem;margin-bottom:1.5rem">
        <form method="POST" action="<?= APP_URL ?>/api/ban-user.php">
            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
            <div class="form-group">
                <label class="form-label">Ban Reason</label>
                <input type="text" name="reason" class="form-input" placeholder="Reason..." required>
            </div>
            <div style="display:flex;gap:8px">
                <button type="submit" class="btn btn-danger">🚫 Confirm Ban</button>
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('bform').style.display='none'">Cancel</button>
            </div>
        </form>
    </div>

    <!-- Stats -->
    <div class="stats-grid" style="margin-bottom:1.5rem">
        <div class="stat-card"><div class="stat-label">QR Codes</div><div class="stat-value" style="color:var(--accent)"><?= $user['qr_count'] ?></div></div>
        <div class="stat-card"><div class="stat-label">Joined</div><div class="stat-value" style="font-size:1rem"><?= date('d M Y',strtotime($user['created_at'])) ?></div></div>
        <div class="stat-card"><div class="stat-label">Last Login</div><div class="stat-value" style="font-size:1rem"><?= $user['last_login'] ? date('d M Y',strtotime($user['last_login'])) : 'Never' ?></div></div>
    </div>

    <!-- QRs -->
    <div class="card">
        <div class="card-header"><span class="card-title">QR Codes (<?= count($userQRs) ?>)</span></div>
        <?php if (empty($userQRs)): ?>
            <div style="padding:2rem;text-align:center;color:var(--text-muted)">No QR codes created yet</div>
        <?php else: ?>
            <div style="max-height:400px;overflow-y:auto;display:flex;flex-direction:column;gap:8px;padding:1rem">
                <?php foreach ($userQRs as $q): ?>
                    <div style="display:flex;align-items:center;gap:10px;padding:10px;background:var(--bg-hover);border-radius:8px">
                        <?php if ($q['qr_image']): ?><img src="<?= $q['qr_image'] ?>" style="width:36px;height:36px;background:white;padding:2px;border-radius:4px"><?php endif; ?>
                        <div style="flex:1;overflow:hidden">
                            <div style="font-weight:600;font-size:.875rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($q['title']) ?></div>
                            <div style="font-size:.75rem;color:var(--text-muted)"><?= date('d M Y',strtotime($q['created_at'])) ?></div>
                        </div>
                        <span class="badge badge-blue"><?= $q['scan_count'] ?> scans</span>
                        <span class="badge badge-purple"><?= $q['type'] ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
